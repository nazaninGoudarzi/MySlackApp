package nazanintorabigoudarzi.detf.android.com.mythirdapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Full_Information extends AppCompatActivity {

    public int counter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full__information);


    }

    public void setter(int counter){
        this.counter = counter;
    }
}
