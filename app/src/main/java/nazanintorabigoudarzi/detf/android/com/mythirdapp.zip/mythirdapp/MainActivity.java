package nazanintorabigoudarzi.detf.android.com.mythirdapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static String[] title = new String[1000];
    public static String[] tag = new String[1000];
    public static String[] image = new String[1000];
    public static String[] name = new String[1000];
    public static boolean[] score = new boolean[1000];
    public static int[] VC = new int[1000];
    public static int b = 0;



    private static final String URL_DATA = "http://api.stackexchange.com/2.2/questions?page=1&pagesize=10&order=desc&sort=activity&site=stackoverflow";
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
  private List<ListItem> listItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView)findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listItems = new ArrayList<>();


        loadRecyclerViewData();
        recyclerView.setAdapter(new MyAdapter(listItems,this));
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);


    }

    private void loadRecyclerViewData() {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading data ... ");
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL_DATA,
            new Response.Listener<String>() {
                @Override
                 public void onResponse(String response) {
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray array = jsonObject.getJSONArray("items");

                        for(int i=0;i<array.length();i++){
                            JSONObject o = array.getJSONObject(i);
                            ListItem item =new ListItem(o.getString("title"),o.getJSONArray("tags").toString().replace("\"",""),
                                    o.getJSONObject("owner").getString("profile_image"),o.getBoolean("is_answered"));
                            listItems.add(item);

                         /*   title[b] = o.getString("title");
                            tag[b] = o.getJSONArray("tags").toString().replace("\"", "");
                            image[b] = o.getJSONObject("owner").getString("profile_image");
                            name[b] = o.getJSONObject("owner").getString("display_name");
                            score[b] = o.getBoolean("score");
                            VC[b] = o.getInt("view_count");*/
                        }
                      /*  for(int b=0;b<array.length();b++) {
                            JSONObject j = array.getJSONObject(b);
                            title[b] = j.getString("title");
                            tag[b] = j.getJSONArray("tags").toString().replace("\"", "");
                            image[b] = j.getJSONObject("owner").getString("profile_image");
                            name[b] = j.getJSONObject("owner").getString("display_name");
                            score[b] = j.getBoolean("score");
                            VC[b] = j.getInt("view_count");
                        }
*/

                        adapter = new MyAdapter(listItems,getApplicationContext());
                        recyclerView.setAdapter(adapter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
        },
             new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(),error.getLocalizedMessage(),Toast.LENGTH_LONG).show();
                    }
         });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
